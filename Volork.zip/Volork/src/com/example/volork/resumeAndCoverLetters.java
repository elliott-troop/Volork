package com.example.volork;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class resumeAndCoverLetters extends ActionBarActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_template_choice);
	}
	
	public void goToResumeTemplates(View v)
	{
		Intent intent = new Intent(this, resumeTemplates.class);
		startActivity(intent);
	}
	
	public void goToCoverLetterTemplates(View v)
	{
		Intent intent = new Intent(this, coverLetterTemplates.class);
		startActivity(intent);
	}
}

