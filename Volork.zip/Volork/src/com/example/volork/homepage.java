package com.example.volork;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


public class homepage extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        //Intent intent = getIntent();
    }
    
    public void goToIndeed(View V)
    {
    	Uri uri = Uri.parse("http://www.indeed.com/jobs?q=&l=Newark%2C+NJ"); // missing 'http://' will cause crashed
    	Intent intent = new Intent(Intent.ACTION_VIEW, uri);
    	startActivity(intent); 
    }
    
    public void goToCommunityVolunteer(View V)
    {
    	Uri uri = Uri.parse("http://www.indeed.com/jobs?q=Community+Volunteer&l=Newark%2C+NJ"); // missing 'http://' will cause crashed
    	Intent intent = new Intent(Intent.ACTION_VIEW, uri);
    	startActivity(intent); 
    }
}
