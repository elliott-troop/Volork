package com.example.volork;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class coverLetterTemplates extends ActionBarActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resume_templates);
	}
	
	public void openCoverLetter1(View v)
	{
		Intent intent = new Intent(this, firstCoverLetter.class);
		startActivity(intent);
	}
	
	public void openCoverLetter2(View v)
	{
		Intent intent = new Intent(this, secondCoverLetter.class);
		startActivity(intent);
	}
	
	public void openCoverLetter3(View v)
	{
		Intent intent = new Intent(this, thirdCoverLetter.class);
		startActivity(intent);
	}
}
