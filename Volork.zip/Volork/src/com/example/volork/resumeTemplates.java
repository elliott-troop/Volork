package com.example.volork;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class resumeTemplates extends ActionBarActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resume_templates);
	}
	
	public void openResume1(View v)
	{
		Intent intent = new Intent(this, firstResume.class);
		startActivity(intent);
	}
	
	public void openResume2(View v)
	{
		Intent intent = new Intent(this, secondResume.class);
		startActivity(intent);
	}
	
	public void openResume3(View v)
	{
		Intent intent = new Intent(this, thirdResume.class);
		startActivity(intent);
	}
}
