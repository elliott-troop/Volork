package com.example.volork;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void goToOptionTo(View v)
	{
		Intent intent = new Intent(this, homepage.class);
		startActivity(intent);
	}
	
	public void goToTemplates(View v)
	{
		Intent intent = new Intent(this, resumeAndCoverLetters.class);
		startActivity(intent);
	}
	
	public void goToAboutPage(View v)
	{
		Intent intent = new Intent(this, aboutPage.class);
		startActivity(intent);
	}
}
